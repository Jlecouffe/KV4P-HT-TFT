#pragma once

#include <Arduino.h>

void displaySetup();
void displayLoop();