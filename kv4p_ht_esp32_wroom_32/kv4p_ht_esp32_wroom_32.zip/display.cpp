#include "display.h"

#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>

// ============================================================
// KV4P-HT + TPM408 2.8" 240x320 ILI9341
// ============================================================

#define TFT_SCK   22
#define TFT_MOSI  21
#define TFT_CS    27
#define TFT_DC    26
#define TFT_RST   -1

// Pas besoin de MISO pour notre premier test.
// L'ILI9341 est utilisé ici en écriture seule.
#define TFT_MISO  -1

// SPI secondaire de l'ESP32
SPIClass tftSPI(VSPI);

// ILI9341
Adafruit_ILI9341 tft(
    &tftSPI,
    TFT_CS,
    TFT_DC,
    TFT_RST
);

static uint32_t lastDisplayUpdate = 0;

void displaySetup()
{
    Serial.println("Initializing TFT...");

    // Initialisation SPI avec notre propre mapping GPIO
    tftSPI.begin(
        TFT_SCK,
        TFT_MISO,
        TFT_MOSI,
        TFT_CS
    );

    // Initialisation écran
    tft.begin();

    // Orientation portrait
    tft.setRotation(0);

    // Écran noir
    tft.fillScreen(ILI9341_BLACK);

    // --------------------------------------------------------
    // TEST DE COULEURS
    // --------------------------------------------------------

    tft.fillScreen(ILI9341_RED);
    delay(300);

    tft.fillScreen(ILI9341_GREEN);
    delay(300);

    tft.fillScreen(ILI9341_BLUE);
    delay(300);

    // --------------------------------------------------------
    // ÉCRAN DE TEST
    // --------------------------------------------------------

    tft.fillScreen(ILI9341_BLACK);

    tft.setTextColor(ILI9341_WHITE);
    tft.setTextSize(3);

    tft.setCursor(25, 40);
    tft.println("KV4P-HT");

    tft.setTextSize(2);

    tft.setCursor(25, 100);
    tft.println("TFT TEST OK");

    tft.setCursor(25, 135);
    tft.println("ILI9341");

    tft.setCursor(25, 170);
    tft.println("240 x 320");

    tft.drawRect(15, 15, 210, 210, ILI9341_WHITE);

    tft.setTextSize(1);

    tft.setCursor(25, 240);
    tft.println("SPI");

    tft.setCursor(25, 255);
    tft.println("SCK  : GPIO22");

    tft.setCursor(25, 270);
    tft.println("MOSI : GPIO21");

    tft.setCursor(25, 285);
    tft.println("CS   : GPIO27");

    tft.setCursor(25, 300);
    tft.println("DC   : GPIO26");

    Serial.println("TFT initialized.");
}

void displayLoop()
{
    // Pour l'instant, rien à rafraîchir.
    // Cette fonction sera utilisée à l'étape suivante.
}